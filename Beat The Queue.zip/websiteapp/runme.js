const express = require('express')

const app = express();

app.use(express.static('assets'))

app.set("view engine","ejs");


app.get('/', function(req, res) 
{
  	res.render('index.ejs',{title: "Home Page"});
})

app.get('/login', function(req, res) 
{
  	res.render('login.ejs',{title: "Login Page"});
})

app.get('/register', function(req, res) 
{
  	res.render('register.ejs',{title: "Register Page"});
})



app.listen(8000, () => {
  console.log('Server running at http://127.0.0.1:8000/')
});